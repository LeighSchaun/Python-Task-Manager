
# Importing date module
from datetime import date
import calendar


# creating list that will latr be used to stor input and data from text files
tasks = []
users_names = []
users_password = []

# Defining the date function that will collect and convert dates
def get_date():
    todays_date = date.today()
    current_year = todays_date.year
    current_month = todays_date.month
    current_day = todays_date.day
    month_abbr = calendar.month_abbr[current_month]
    
    return f"{current_day} {month_abbr} {current_year}"

# Defining the register user function that takes current username and current_usernames list as arguments
def reg_user(current_user, current_usernames):
    print("Please register new user.")
    print()
    # Checks if the current user is logged in as admin
    if current_user == "admin":
        new_username = input("Please enter the new username: ")
        new_password = input("Please enter the new password: ")
        confirm_new_password = input("Please confirm the new password: ")

        # While loop to check if the user exists in the current users list
        while new_username in current_usernames:
            new_username = input("Sorry That user already exists please enter "
            "a different username: ")
        # If the username entered does not exist,the user can adda anew user
        if new_password == confirm_new_password:
            users_names.append(new_username)
            users_password.append(new_password)

            # Opens the text file that contains the current user details
            with open('user.txt', 'w', encoding='utf-8') as write_user:
                # Loops through the current users
                for index in range(len(users_names)):

                    # Writes the new user to the user.txt file
                    write_user.write(f"{users_names[index]}, "
                                        f"{users_password[index]}\n")
            # Lets the user know the new yser has been added
            print("New user added successfully")

        # Message displayed if the passwords entered does not match
        else:
            print("The new password does not match what you entered as the "
                    "confirmation password, Please try again.")
    # Displays if the user is not Admin
    else:
        print("Registering users is restricted to Admin access only")

# Defining a function to add a new task
def add_task():
    print("Please add a new task")
    print()

    #Prompts user for details of the new 
    new_task_user = input("Please enter the user for the new task: ")
    new_task_title = input("Please enter the task title for the new "
                            "task: ")
    new_task_des = input("Please enter the task description for the new "
                            "task: ")

    new_task_date = date.today()
    
    new_task_due = input("Please enter the task due date for the new "
                            "task in this format '06 Jan 2022': ")
    new_task_status = "No"

    new_task = f"{new_task_user}, {new_task_title}, {new_task_des}, "\
                f"{new_task_date}, {new_task_due}, {new_task_status}"
    

    # Adds the new task to the taks list
    tasks.append(new_task)

    
    # Opens the tasks file to append the new task to the file
    with open('tasks.txt', 'a', encoding='utf-8') as write_tasks:
        
        for index in range(len(tasks)):
            write_tasks.write('\n' + new_task)

# Defining a function to view all tasks
def view_all():
    print("Below is a list of your tasks")
    print()

    # Loops through tasks in the text file
    for task in tasks:
        task = task.split(", ")

        # Prints the task a easy to read manner for the user
        print(f"Assigned to:\t\t{task[0]}\nTask title:\t\t{task[1]}\n"
            f"Task description:\t{task[2]}\nAssigned date:\t\t{task[3]}\n"
            f"Due date:\t\t{task[4]}\nTask completed:\t\t{task[5]}\n")

# Defining a function to view all tasks entered
def view_mine():
    print("Below is a list of all tasks")
    print()

    # Creating a for loop to find the index of each tasks
    for index, task in enumerate(tasks):
        task = task.split(",")

        # checks which user is logged in and prints the tasks for that user
        if task[0] == username:

            # Prints the list of tasks associated to the user logged in
            print(f"Assigned to:\t\t {task[0]}\nTask title:\t\t{task[1]}\n"
                f"Task description:\t{task[2]}\nAssigned date:\t\t{task[3]}\n"
                f"Due date:\t\t{task[4]}\nTask completed:\t\t{task[5]}\n"
                )
# Defining a function to display the overview of users and tasks
def task_ov():

    # Checks if the user logged in is admin
    if username == "admin" and user_selection == "ov":

        # opens tasks file
        with open ('tasks.txt','r') as taskfile:

            # set task counter to 0
            count_tasks = 0

            # reads through lines in task file
            task_overview = taskfile.readlines()

            # counts lines in task file to establishe how many tasks exist
            count_tasks= sum(1 for line1 in task_overview)

    

        # opens user file
        with open ('user.txt','r') as userfile:
    
            # checks the length of the file by reading through the lines
            lines = len(userfile.readlines())
    

            # creates a dictionary storing the overview statistics
            overview = {"Total users registered:\t":lines,"Total Tasks:\t\t":count_tasks}

            # prnts the statistics
            for key,value in overview.items():

                # prints the overview
                print(key,value)

                print()
            

# Reads the task file
with open('tasks.txt', 'r', encoding='utf-8') as read_tasks:
    for task in read_tasks:
        task = task.strip("\n")
        tasks.append(task)

# reads the user file and creates a user and password list
with open('user.txt', 'r', encoding='utf-8') as read_user:
    for user in read_user:
        user = user.replace(",", "")
        user = user.strip("\n")
        user = user.split(" ")
        users_names.append(user[0])
        users_password.append(user[-1])

# Sets logged in status to false
logged_in = False

# While loop to continue if the logged in stays false
while not logged_in:
    
    print("Welcome to your task manager")
    print()

    # Requests login detials from user
    username = input("Enter your username: ")
    password = input("Enter your password: ")

    # Checks if the log username exist in the username list
    while username not in users_names:
        username = input("Invalid username entered, please try again: ")

    # assigns the username to the user index
    user_index = users_names.index(username)

    print("")

    # Executes if the username exists and sets logged in to True
    if (username == users_names[user_index]) and (password ==
        users_password[user_index]):
        logged_in = True
        print("Successfully logged in")
        print()

    # Checks f either username or passwords are entered correctly
    elif (username == users_names[user_index]) and (password !=
            users_password[user_index]):
        print("User not logged in, Correct username entered with incorrect "
                "password.")

    elif (username not in users_names) and (password in users_password):
        print("User not logged in, Incorrect username entered with correct "
                "password.")

    elif (username not in users_names) and (password not in users_password):
        print("User not logged in, Incorrect username entered with incorrect "
                "password.")

# Executes when logged in changes to True
while logged_in:

    # Check if the user logged in s admin to display the appropriate menu 
    if username == "admin":
        user_selection = input('''Select one of the following Options below:
r - Registering a user
a - Adding a task
va - View all tasks
vm - view my task
ov - overview
e - Exit
: ''').lower()

# This menu is displayed if the user is not admin
    else:
        user_selection = input('''Select one of the following Options below:
a - Adding a task
va - View all tasks
vm - view my task
e - Exit
: ''').lower()

    # Calls the function to add new user if r is selected
    if user_selection == "r":
        reg_user(username, users_names)

    # Calls the function to add new task if a
    elif user_selection == "a":
        add_task()
    # Calls the function to view all tasks if va is selected
    elif user_selection == "va":
        view_all()

    # Calls the function to view my task if vm is selected
    elif user_selection == "vm":
        view_mine()
    # Calls the functon to view the overview if ov is selected
    elif user_selection == "ov":

        task_ov()


    # This ends the program if the user has selected 'e'
    elif user_selection == "e":
        

        print('Goodbye!!!')

        # closes the program
        exit()

        
    # if incorrect option is selected
    else:
        print("Something was entered that isn't on the list, Please try to "
                "enter your selection again.")


